import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        bg: {
          DEFAULT: "var(--bg)",
          raised: "var(--bg-raised)",
        },
        ink: "var(--ink)",
        muted: "var(--muted)",
        champagne: {
          DEFAULT: "var(--champagne)",
          hi: "var(--champagne-hi)",
        },
        line: "var(--line)",
        "line-strong": "var(--line-strong)",
        ivory: "var(--ivory)",
        beige: "var(--beige)",
        espresso: {
          DEFAULT: "var(--espresso)",
          soft: "var(--espresso-soft)",
        },
        "card-line": "var(--card-line)",
        "card-line-strong": "var(--card-line-strong)",
      },
      fontFamily: {
        sans: ["var(--font-grotesk)", "system-ui", "sans-serif"],
        serif: ["var(--font-serif)", "Georgia", "serif"],
        mono: ["var(--font-mono)", "ui-monospace", "monospace"],
      },
      fontSize: {
        eyebrow: ["0.78125rem", { lineHeight: "1.4", letterSpacing: "0.14em" }],
        "display-xl": [
          "clamp(2.7rem, 7.2vw, 6.2rem)",
          { lineHeight: "1.0", letterSpacing: "-0.03em" },
        ],
        "display-lg": [
          "clamp(2rem, 4.4vw, 3.5rem)",
          { lineHeight: "1.05", letterSpacing: "-0.02em" },
        ],
      },
      borderRadius: {
        card: "1.5rem",
        mock: "1.25rem",
        soft: "0.875rem",
      },
      maxWidth: {
        container: "1320px",
      },
      boxShadow: {
        soft: "0 1px 2px rgba(0,0,0,.3), 0 12px 40px rgba(0,0,0,.4)",
        lift: "0 2px 4px rgba(0,0,0,.35), 0 24px 60px rgba(0,0,0,.55)",
      },
      transitionTimingFunction: {
        expo: "cubic-bezier(0.22, 1, 0.36, 1)",
      },
    },
  },
  plugins: [],
};

export default config;
