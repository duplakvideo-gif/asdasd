export type Service = {
  name: string;
  duration: string;
  price: string;
};

export const services: Service[] = [
  { name: "Strih + brada", duration: "60 min", price: "30 €" },
  { name: "Farbenie + styling", duration: "120 min", price: "od 69 €" },
  { name: "Masáž chrbta", duration: "60 min", price: "45 €" },
];

export const slots = ["09:30", "10:30", "11:00", "13:30", "15:00"] as const;

export const adminItems = [
  "Pracovné dni",
  "Dni voľna",
  "Služby a ceny",
  "Email potvrdenia",
] as const;

export const marqueeItems = [
  "Web do 48 h",
  "Online rezervácie 24/7",
  "Email potvrdenia",
  "Platí sa raz",
  "Vlastná doména",
  "Jednoduchá administrácia",
] as const;

export const problems = [
  {
    channel: "Instagram",
    text: "„Dobrý deň, máte voľno v piatok?“",
    note: "Správa medzi desiatkami iných.",
  },
  {
    channel: "Zmeškaný hovor",
    text: "2 zmeškané hovory počas strihania",
    note: "Klient už nezavolá späť.",
  },
  {
    channel: "Papierový diár",
    text: "Pondelok 14:00 — alebo 15:00?",
    note: "Nečitateľný zápis, prepisovanie.",
  },
  {
    channel: "Messenger",
    text: "Dvaja klienti na rovnaký čas",
    note: "Dvojitá rezervácia, trápne ráno.",
  },
];

export const benefits = [
  {
    title: "Prezentačný web",
    text: "Moderná stránka s vašimi službami, cenami a fotkami. Vyzeráte profesionálne ešte pred prvým kontaktom.",
  },
  {
    title: "Rezervácie priamo z webu",
    text: "Klient si vyberie službu a voľný termín. Bez telefonátov, bez čakania na odpoveď.",
  },
  {
    title: "Email potvrdenie",
    text: "Klient aj vy dostanete potvrdenie e-mailom. Termín je jasný a zapísaný na jednom mieste.",
  },
  {
    title: "Jednoduchá administrácia",
    text: "Pracovné dni, dni voľna, služby a ceny upravíte v prehľadnom paneli. Bez technických znalostí.",
  },
];

export const steps = [
  {
    no: "01",
    title: "Poviete nám o svojej prevádzke",
    text: "Služby, ceny, otváracie hodiny a pár fotiek. Stačí krátky rozhovor — ukážku webu dostanete zadarmo.",
  },
  {
    no: "02",
    title: "Postavíme web aj rezervácie",
    text: "Prezentačný web s vašou značkou a rezervačným systémom. Doplníme pracovné dni a otestujeme celý priebeh.",
  },
  {
    no: "03",
    title: "Do 48 hodín ste online",
    text: "Web ide naživo. Klienti rezervujú sami, vy máte termíny prehľadne na jednom mieste.",
  },
];

/* TODO: nahradiť Unsplash placeholdery fotkami reálnych prevádzok */
export const audience = [
  {
    title: "Kaderníctva",
    text: "Strihy, farbenie, styling.",
    img: "https://images.unsplash.com/photo-1560066984-138dadb4c035?w=800&q=70&auto=format&fit=crop",
  },
  {
    title: "Barbershopy",
    text: "Strih, brada, kontúry.",
    img: "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=800&q=70&auto=format&fit=crop",
  },
  {
    title: "Kozmetika",
    text: "Ošetrenia, mihalnice, obočie.",
    img: "https://images.unsplash.com/photo-1487412947147-5cebf100ffc2?w=800&q=70&auto=format&fit=crop",
  },
  {
    title: "Wellness",
    text: "Sauna, procedúry, balíčky.",
    img: "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=800&q=70&auto=format&fit=crop",
  },
  {
    title: "Masáže",
    text: "Relaxačné aj športové masáže.",
    img: "https://images.unsplash.com/photo-1600334129128-685c5582fd35?w=800&q=70&auto=format&fit=crop",
  },
  {
    title: "Nechtové štúdiá",
    text: "Nechty, manikúra, pedikúra.",
    img: "https://images.unsplash.com/photo-1604654894610-df63bc536371?w=800&q=70&auto=format&fit=crop",
  },
];

/* ----------------------------- Cenník ----------------------------- */

/* TODO: potvrdiť výšku ročného poplatku za prevádzku (hosting, doména, zálohy) */
export const pricing = {
  oneTime: {
    tag: "Odporúčame",
    name: "Jednorazovo",
    price: "690 €",
    period: "raz a dosť",
    note: "Web aj rezervačný systém sú vaše. Žiadny mesačný poplatok za systém.",
    features: [
      "Prezentačný web na mieru",
      "Online rezervácie priamo z webu",
      "Email potvrdenia pre klienta aj vás",
      "Jednoduchá administrácia",
      "Spustenie do 48 hodín",
      "Google Kalendár ako voliteľný doplnok",
    ],
    hosting:
      "Prevádzka webu (hosting, doména, zálohy): prvý rok v cene, potom 120 €/rok.",
  },
  monthly: {
    tag: "Bez vstupnej investície",
    name: "Mesačne",
    price: "0 € + 59 €",
    period: "mesačne",
    note: "Začnete bez počiatočných nákladov. Rovnaký web, rovnaké rezervácie.",
    features: [
      "Všetko ako pri jednorazovej platbe",
      "Hosting a doména v cene",
      "Priebežné úpravy v cene",
      "Zrušenie kedykoľvek",
    ],
  },
  comparison:
    "Bežné rezervačné systémy stoja 18–50 € mesačne navždy — a stránka je len šablóna, ktorá nikdy nebude vaša.",
} as const;

/* ----------------------------- Referencie ----------------------------- */

export type Reference = {
  quote: string;
  name: string;
  business: string;
};

/*
 * Referencie doplníš pridaním objektov do tohto poľa — sekcia sa
 * automaticky prepne z dočasného stavu na mriežku citátov.
 * Príklad:
 * { quote: "Rezervácie mi chodia samé.", name: "Jana K.", business: "Salón Luna, Poprad" }
 */
export const references: Reference[] = [];

export const referencesEmptyState = {
  title: "Prvé referenčné projekty práve prebiehajú",
  text: "Weby pre prvé salóny sú vo výrobe. Chcete byť medzi prvými — s cenou, ktorá sa už nebude opakovať?",
} as const;

/* ----------------------------- Kto za tým stojí ----------------------------- */

export const about = {
  eyebrow: "Kto za tým stojí",
  /* TODO: doplniť skutočné meno */
  name: "Martin",
  role: "weby a video pre lokálne prevádzky",
  paragraphs: [
    "Som z Popradu a robím weby a video pre lokálne prevádzky — salóny, štúdiá a služby, kde sa pracuje na termíny.",
    "Nie som anonymná platforma. Keď treba, prídem osobne, nafotíme prevádzku a doladíme detaily pri káve.",
    "Web vám odovzdám hotový a naučím vás ovládať administráciu za desať minút.",
  ],
} as const;
