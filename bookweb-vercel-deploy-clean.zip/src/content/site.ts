export const site = {
  name: "BookWEB",
  domain: "bookweb.sk",
  positioning: "Web, ktorý prijíma rezervácie.",
  email: "ahoj@bookweb.sk",
  /* TODO: doplniť skutočné telefónne číslo */
  phone: "+421 9XX XXX XXX",
  phoneHref: "tel:+4219XXXXXXXX",
  /* TODO: nasadiť demo a doplniť reálnu URL */
  demoUrl: "https://demo.bookweb.sk",
  city: "Poprad",
} as const;

export const nav = [
  { label: "Ako to funguje", href: "#demo" },
  { label: "Čo dostanete", href: "#vyhody" },
  { label: "Cenník", href: "#cennik" },
  { label: "Kto za tým stojí", href: "#o-mne" },
] as const;

/** Primárne CTA — všade rovnaké, kotva na formulár. */
export const cta = {
  primary: "Chcem ukážku zadarmo",
  primaryHref: "#dopyt",
  secondary: "Pozrieť demo",
} as const;
