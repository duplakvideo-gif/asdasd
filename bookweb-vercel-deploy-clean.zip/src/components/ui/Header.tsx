"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { nav, site, cta } from "@/content/site";
import { cn } from "@/lib/utils";

export function Header() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 16);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.header
      initial={{ y: -24, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-colors duration-300 ease-expo",
        scrolled ? "border-b border-line bg-bg/85 backdrop-blur-md" : "bg-transparent",
      )}
    >
      <div
        className={cn(
          "mx-auto flex max-w-container items-center justify-between px-5 transition-all duration-300 ease-expo md:px-8",
          scrolled ? "py-3" : "py-5",
        )}
      >
        <a href="#top" className="flex items-baseline gap-1 font-mono text-base font-bold tracking-tight text-ink">
          Book<span className="text-champagne">WEB</span>
          <span className="ml-1 hidden text-[10px] font-normal uppercase tracking-widest text-muted sm:inline">
            .sk
          </span>
        </a>

        <nav className="hidden items-center gap-1 lg:flex">
          {nav.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="rounded-full px-4 py-1.5 text-sm text-muted transition-colors hover:text-ink"
            >
              {item.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-2 sm:gap-3">
          {/* TODO: nahradiť placeholder telefónne číslo skutočným */}
          <a
            href={site.phoneHref}
            className="group flex items-center gap-2 rounded-full border border-line px-3 py-2.5 text-sm text-ink transition-colors duration-300 hover:border-champagne hover:text-champagne-hi sm:px-4"
            aria-label={`Zavolať na ${site.phone}`}
          >
            <svg viewBox="0 0 16 16" className="h-4 w-4" fill="none" aria-hidden>
              <path
                d="M3.2 1.8h2.4l1.1 3-1.5 1.2a9.5 9.5 0 004.8 4.8l1.2-1.5 3 1.1v2.4a1.3 1.3 0 01-1.4 1.3A12.7 12.7 0 011.9 3.2a1.3 1.3 0 011.3-1.4z"
                stroke="currentColor"
                strokeWidth="1.3"
                strokeLinejoin="round"
              />
            </svg>
            <span className="hidden font-mono text-xs md:inline">{site.phone}</span>
          </a>

          <a
            href={cta.primaryHref}
            className="rounded-full bg-champagne px-4 py-2.5 text-sm font-medium text-bg transition-all duration-300 ease-expo hover:-translate-y-0.5 hover:bg-champagne-hi sm:px-5"
          >
            {cta.primary}
          </a>
        </div>
      </div>
    </motion.header>
  );
}
