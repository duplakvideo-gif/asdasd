import { cn } from "@/lib/utils";

type ButtonProps = {
  href: string;
  children: React.ReactNode;
  variant?: "primary" | "ghost";
  className?: string;
  arrow?: boolean;
};

const base =
  "group inline-flex items-center justify-center gap-2 rounded-full px-7 py-3.5 text-sm font-medium tracking-tight transition-all duration-300 ease-expo";

const variants = {
  primary:
    "bg-champagne text-bg hover:-translate-y-0.5 hover:bg-champagne-hi hover:shadow-lift",
  ghost:
    "border border-line-strong bg-transparent text-ink hover:border-champagne hover:text-champagne-hi hover:-translate-y-0.5",
};

export function Button({
  href,
  children,
  variant = "primary",
  className,
  arrow = true,
}: ButtonProps) {
  return (
    <a href={href} className={cn(base, variants[variant], className)}>
      {children}
      {arrow && (
        <svg
          className="h-4 w-4 transition-transform duration-300 ease-expo group-hover:translate-x-1"
          viewBox="0 0 16 16"
          fill="none"
          aria-hidden
        >
          <path
            d="M3 8h10M9 4l4 4-4 4"
            stroke="currentColor"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      )}
    </a>
  );
}
