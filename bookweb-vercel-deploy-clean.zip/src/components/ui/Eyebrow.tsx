import { cn } from "@/lib/utils";

export function Eyebrow({
  no,
  children,
  className,
}: {
  /** Číslo sekcie, napr. "01" — signature číslovanie cez celý web. */
  no?: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-3 font-mono text-eyebrow uppercase text-muted",
        className,
      )}
    >
      {no && <span className="text-champagne">{no}</span>}
      <span className="h-px w-6 bg-line-strong" aria-hidden />
      {children}
    </span>
  );
}
