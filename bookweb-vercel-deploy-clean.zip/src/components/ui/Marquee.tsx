import { marqueeItems } from "@/content/data";

export function Marquee() {
  const row = (ariaHidden: boolean) => (
    <span aria-hidden={ariaHidden || undefined} className="flex shrink-0">
      {marqueeItems.map((item) => (
        <span
          key={item}
          className="flex items-center py-3 font-serif text-xl italic text-ink/90 sm:py-4 sm:text-3xl"
        >
          <span className="px-5 sm:px-8">{item}</span>
          <span
            className="inline-block h-1.5 w-1.5 rotate-45 bg-champagne"
            aria-hidden
          />
        </span>
      ))}
    </span>
  );

  return (
    <div className="marquee" role="presentation">
      <div className="marquee-track">
        {row(false)}
        {row(true)}
      </div>
    </div>
  );
}
