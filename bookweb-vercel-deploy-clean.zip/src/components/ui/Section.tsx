import { cn } from "@/lib/utils";

type SectionProps = {
  id?: string;
  className?: string;
  children: React.ReactNode;
};

export function Section({ id, className, children }: SectionProps) {
  return (
    <section id={id} className={cn("relative w-full", className)}>
      <div className="mx-auto w-full max-w-container px-6 md:px-8">{children}</div>
    </section>
  );
}
