import { site, nav } from "@/content/site";

export function Footer() {
  return (
    <footer className="hairline">
      <div className="mx-auto grid max-w-container grid-cols-1 gap-10 px-5 py-14 md:grid-cols-[1.2fr_1fr_1fr] md:px-8">
        <div>
          <p className="font-mono text-base font-bold tracking-tight text-ink">
            Book<span className="text-champagne">WEB</span>
            <span className="ml-1 text-[10px] font-normal uppercase tracking-widest text-muted">
              .sk
            </span>
          </p>
          <p className="mt-3 max-w-xs text-sm leading-relaxed text-muted">
            Prezentačné weby s rezervačným systémom pre salóny a lokálne
            služby. Spustenie do 48 hodín.
          </p>
        </div>

        <nav aria-label="Päta — navigácia">
          <p className="font-mono text-[11px] uppercase tracking-[0.14em] text-muted">
            Web
          </p>
          <ul className="mt-4 space-y-2.5">
            {nav.map((item) => (
              <li key={item.href}>
                <a
                  href={item.href}
                  className="text-sm text-ink/80 transition-colors hover:text-champagne-hi"
                >
                  {item.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div>
          <p className="font-mono text-[11px] uppercase tracking-[0.14em] text-muted">
            Kontakt
          </p>
          <ul className="mt-4 space-y-2.5 text-sm">
            <li>
              {/* TODO: doplniť skutočné telefónne číslo */}
              <a
                href={site.phoneHref}
                className="text-ink/80 transition-colors hover:text-champagne-hi"
              >
                {site.phone}
              </a>
            </li>
            <li>
              <a
                href={`mailto:${site.email}`}
                className="text-ink/80 transition-colors hover:text-champagne-hi"
              >
                {site.email}
              </a>
            </li>
            <li>
              <a
                href="/ochrana-osobnych-udajov"
                className="text-ink/80 transition-colors hover:text-champagne-hi"
              >
                Ochrana osobných údajov
              </a>
            </li>
          </ul>
        </div>
      </div>

      <div className="hairline">
        <div className="mx-auto flex max-w-container flex-col gap-1 px-5 py-6 font-mono text-[11px] text-muted md:flex-row md:items-center md:justify-between md:px-8">
          {/* TODO: doplniť obchodné meno a IČO */}
          <p>
            © {new Date().getFullYear()} BookWEB · [Obchodné meno] · IČO:
            [doplniť]
          </p>
          <p>Web, ktorý prijíma rezervácie.</p>
        </div>
      </div>
    </footer>
  );
}
