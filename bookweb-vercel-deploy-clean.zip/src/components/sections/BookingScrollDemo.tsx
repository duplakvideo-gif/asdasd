"use client";

import { useEffect, useRef, useState } from "react";
import {
  AnimatePresence,
  motion,
  useMotionValueEvent,
  useScroll,
  useTransform,
  type MotionValue,
} from "framer-motion";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { services, slots, adminItems } from "@/content/data";
import { expoOut } from "@/lib/motion";

const stages = [
  {
    label: "Web",
    title: "Klient otvorí váš web",
    text: "Vidí vaše služby, ceny a dĺžku každého úkonu. Prehľadne, na jednom mieste.",
  },
  {
    label: "Výber služby",
    title: "Vyberie si službu",
    text: "„Strih + brada“ — jeden klik. Žiadne telefonáty, žiadne čakanie na odpoveď.",
  },
  {
    label: "Termín",
    title: "Zvolí voľný termín",
    text: "Kalendár ukáže len reálne voľné časy. Klient si vyberie 11:00.",
  },
  {
    label: "Potvrdenie",
    title: "Rezervácia potvrdená",
    text: "Termín sa hneď zapíše. Žiadne dvojité rezervácie, žiadny zmätok.",
  },
  {
    label: "E-mail",
    title: "Potvrdenie e-mailom",
    text: "Klient aj vy dostanete potvrdenie do schránky. Termín je čierny na bielom.",
  },
  {
    label: "Majiteľ",
    title: "Vy máte prehľad",
    text: "Rezervácia pribudne do administrácie. Pracovné dni, voľno aj služby máte pod kontrolou.",
  },
];

// prahy scrollu, ktoré prepínajú aktívnu fázu
const thresholds = [0.17, 0.34, 0.52, 0.68, 0.85];

/* Farby booking UI (svetlá karta) — literály kvôli framer-motion animáciám */
const cardLine = "rgba(20,17,13,0.1)";
const espresso = "#14110d";
const espressoSoft = "#2b261f";
const ivory = "#faf7f1";
const champagneDeep = "#bd9a5f";
const green = "#1f7a4d";

export function BookingScrollDemo() {
  const ref = useRef<HTMLDivElement>(null);
  const [index, setIndex] = useState(0);
  const [isMobile, setIsMobile] = useState(false);

  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end end"],
  });

  useEffect(() => {
    const mq = window.matchMedia("(max-width: 1023px)");
    const update = () => setIsMobile(mq.matches);
    update();
    mq.addEventListener("change", update);
    return () => mq.removeEventListener("change", update);
  }, []);

  useMotionValueEvent(scrollYProgress, "change", (v) => {
    let next = 0;
    for (let i = 0; i < thresholds.length; i += 1) {
      if (v >= thresholds[i]) next = i + 1;
    }
    setIndex(next);
  });

  return (
    <section
      id="demo"
      ref={ref}
      className="hairline relative"
      style={{ height: "440vh" }}
    >
      <div className="sticky top-0 flex h-screen items-center overflow-hidden">
        <div className="mx-auto grid w-full max-w-container grid-cols-1 items-center gap-8 px-5 md:px-8 lg:grid-cols-2 lg:gap-12">
          {/* ---------------- Ľavá strana: text podľa scrollu ---------------- */}
          <div className="order-2 lg:order-1">
            <Eyebrow no="02">Ako prebieha rezervácia</Eyebrow>

            <div className="relative mt-6 h-[8.5rem] sm:h-[7.5rem]">
              <AnimatePresence mode="wait">
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 14 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.45, ease: expoOut }}
                >
                  <p className="font-mono text-eyebrow uppercase text-champagne">
                    {String(index + 1).padStart(2, "0")} · {stages[index].label}
                  </p>
                  <h3 className="mt-3 text-2xl font-medium tracking-tight text-ink sm:text-3xl">
                    {stages[index].title}
                  </h3>
                  <p className="mt-3 max-w-md text-base leading-relaxed text-muted">
                    {stages[index].text}
                  </p>
                </motion.div>
              </AnimatePresence>
            </div>

            {/* progress rail */}
            <div className="mt-8 flex gap-2">
              {stages.map((s, i) => (
                <div key={s.label} className="flex-1">
                  <div className="h-1 overflow-hidden rounded-full bg-line">
                    <motion.div
                      className="h-full rounded-full bg-champagne"
                      animate={{ width: i <= index ? "100%" : "0%" }}
                      transition={{ duration: 0.5, ease: expoOut }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* ---------------- Pravá strana: sticky booking UI ---------------- */}
          <div className="order-1 flex justify-center lg:order-2">
            <BookingStage
              key={isMobile ? "m" : "d"}
              progress={scrollYProgress}
              tilt={isMobile ? 0.25 : 1}
              index={index}
            />
          </div>
        </div>
      </div>
    </section>
  );
}

function BookingStage({
  progress: p,
  tilt,
  index,
}: {
  progress: MotionValue<number>;
  tilt: number;
  index: number;
}) {
  // orientácia celej karty — pokojný tilt, na konci rotácia k admin panelu
  const cardRotateY = useTransform(
    p,
    [0, 0.5, 0.84, 1],
    [-9 * tilt, -2 * tilt, -2 * tilt, -16 * tilt],
  );
  const cardRotateX = useTransform(p, [0, 0.5, 1], [7 * tilt, 2 * tilt, 4 * tilt]);

  // kalendárový panel — vysúva sa dopredu v 3D
  const calOpacity = useTransform(p, [0.3, 0.4], [0, 1]);
  const calY = useTransform(p, [0.3, 0.44], [80, 0]);
  const calRotX = useTransform(p, [0.3, 0.44], [22 * tilt, 0]);
  const calScale = useTransform(p, [0.3, 0.44], [0.92, 1]);

  // kurzor smerujúci na slot 11:00
  const cursorOpacity = useTransform(p, [0.39, 0.43, 0.5, 0.55], [0, 1, 1, 0]);
  const cursorX = useTransform(p, [0.43, 0.5], [54, 0]);
  const cursorY = useTransform(p, [0.43, 0.5], [70, 0]);

  // diskrétne stavy odvodené z progresu
  const [state, setState] = useState({
    selected: false,
    slotActive: false,
    slotConfirmed: false,
    showConfirm: false,
    showEmail: false,
    showAdmin: false,
  });

  useMotionValueEvent(p, "change", (v) => {
    setState({
      selected: v > 0.18,
      slotActive: v > 0.46,
      slotConfirmed: v > 0.56,
      showConfirm: v > 0.54,
      showEmail: v > 0.7,
      showAdmin: v > 0.86,
    });
  });

  return (
    <div className="stage-3d relative w-full max-w-[23rem]">
      <motion.div
        className="floor-shadow preserve-3d relative"
        style={{ rotateX: cardRotateX, rotateY: cardRotateY }}
      >
        {/* ===== Booking karta (klientsky web — svetlá) ===== */}
        <div className="ui-card preserve-3d overflow-hidden rounded-mock">
          <div className="browser-bar flex items-center gap-2 px-4 py-3">
            <span className="h-2.5 w-2.5 rounded-full bg-[#e0d8c8]" />
            <span className="h-2.5 w-2.5 rounded-full bg-[#e0d8c8]" />
            <span className="h-2.5 w-2.5 rounded-full bg-[#e0d8c8]" />
            <div className="ml-3 flex-1 rounded-full bg-beige/70 px-3 py-1 text-center font-mono text-[11px] text-espresso-soft/60">
              salon-luna.sk
            </div>
          </div>

          <div className="relative p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-base font-semibold tracking-tight">
                  Salón Luna
                </p>
                <p className="text-xs text-espresso-soft/60">Vyberte si službu</p>
              </div>
              <span className="rounded-full bg-beige px-2.5 py-1 text-[10px] font-medium text-espresso-soft">
                Online rezervácia
              </span>
            </div>

            {/* zoznam služieb */}
            <div className="mt-4 space-y-2">
              {services.map((s, i) => {
                const isPick = i === 0;
                const active = isPick && state.selected;
                return (
                  <motion.div
                    key={s.name}
                    animate={{
                      borderColor: active ? champagneDeep : cardLine,
                      backgroundColor: active
                        ? "rgba(230,214,178,0.4)"
                        : "#ffffff",
                    }}
                    transition={{ duration: 0.4, ease: expoOut }}
                    className="flex items-center justify-between rounded-soft border px-3.5 py-2.5"
                  >
                    <div className="flex items-center gap-2.5">
                      <motion.span
                        initial={{
                          borderColor: "rgba(20,17,13,0.16)",
                          backgroundColor: "rgba(189,154,95,0)",
                        }}
                        animate={{
                          borderColor: active
                            ? champagneDeep
                            : "rgba(20,17,13,0.16)",
                          backgroundColor: active
                            ? champagneDeep
                            : "rgba(189,154,95,0)",
                        }}
                        transition={{ duration: 0.35, ease: expoOut }}
                        className="grid h-4 w-4 place-items-center rounded-full border"
                      >
                        <AnimatePresence>
                          {active && (
                            <motion.svg
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              exit={{ scale: 0 }}
                              viewBox="0 0 12 12"
                              className="h-2.5 w-2.5 text-white"
                              fill="none"
                            >
                              <path
                                d="M2.5 6.2l2.2 2.2L9.5 3.6"
                                stroke="currentColor"
                                strokeWidth="1.6"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                              />
                            </motion.svg>
                          )}
                        </AnimatePresence>
                      </motion.span>
                      <div>
                        <p className="text-sm font-medium leading-tight">
                          {s.name}
                        </p>
                        <p className="text-[11px] text-espresso-soft/60">
                          {s.duration}
                        </p>
                      </div>
                    </div>
                    <span className="text-sm font-medium">{s.price}</span>
                  </motion.div>
                );
              })}
            </div>

            {/* kalendárový panel — vysúva sa v 3D */}
            <motion.div
              style={{
                opacity: calOpacity,
                y: calY,
                rotateX: calRotX,
                scale: calScale,
                transformOrigin: "center top",
              }}
              className="preserve-3d mt-4 rounded-soft border border-card-line bg-white/95 p-3.5"
            >
              <div className="flex items-center justify-between">
                <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-espresso-soft/60">
                  Voľný termín — dnes
                </p>
                <span className="font-mono text-[11px] text-espresso-soft/60">
                  Po–Pia
                </span>
              </div>
              <div className="relative mt-3 flex flex-wrap gap-2">
                {slots.map((slot) => {
                  const isTarget = slot === "11:00";
                  const active = isTarget && state.slotActive;
                  const confirmed = isTarget && state.slotConfirmed;
                  return (
                    <motion.span
                      key={slot}
                      animate={{
                        borderColor: confirmed
                          ? green
                          : active
                            ? espresso
                            : cardLine,
                        backgroundColor: confirmed
                          ? green
                          : active
                            ? espresso
                            : "#ffffff",
                        color: confirmed || active ? ivory : espressoSoft,
                      }}
                      transition={{ duration: 0.35, ease: expoOut }}
                      className="inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium"
                    >
                      {confirmed && (
                        <motion.svg
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          viewBox="0 0 12 12"
                          className="h-3 w-3"
                          fill="none"
                        >
                          <path
                            d="M2.5 6.2l2.2 2.2L9.5 3.6"
                            stroke="currentColor"
                            strokeWidth="1.6"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </motion.svg>
                      )}
                      {slot}
                    </motion.span>
                  );
                })}

                {/* kurzor */}
                <motion.span
                  style={{ opacity: cursorOpacity, x: cursorX, y: cursorY }}
                  className="pointer-events-none absolute left-[5.4rem] top-1 z-10"
                >
                  <span className="block h-4 w-4 rounded-full border-2 border-espresso bg-white/60" />
                </motion.span>
              </div>
            </motion.div>
          </div>
        </div>

        {/* ===== Potvrdzovací chip ===== */}
        <AnimatePresence>
          {state.showConfirm && !state.showAdmin && (
            <motion.div
              initial={{ opacity: 0, y: 16, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 16, scale: 0.95 }}
              transition={{ duration: 0.5, ease: expoOut }}
              className="ui-card absolute -bottom-7 -left-5 flex items-center gap-3 rounded-2xl px-4 py-3"
              style={{ transform: "translateZ(70px)" }}
            >
              <span className="grid h-9 w-9 place-items-center rounded-full bg-[#1f7a4d] text-ivory">
                <svg viewBox="0 0 16 16" className="h-4 w-4" fill="none" aria-hidden>
                  <path
                    d="M3.5 8.5l2.8 2.8 6-6.2"
                    stroke="currentColor"
                    strokeWidth="1.8"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </span>
              <div>
                <p className="text-sm font-semibold leading-tight">
                  Rezervácia potvrdená
                </p>
                <p className="text-xs text-espresso-soft/60">
                  Strih + brada · 11:00
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ===== Email chip ===== */}
        <AnimatePresence>
          {state.showEmail && !state.showAdmin && (
            <motion.div
              initial={{ opacity: 0, x: 24, y: -6 }}
              animate={{ opacity: 1, x: 0, y: 0 }}
              exit={{ opacity: 0, x: 24 }}
              transition={{ duration: 0.5, ease: expoOut }}
              className="ui-card absolute -right-6 top-6 flex w-[12.5rem] items-start gap-3 rounded-2xl px-4 py-3"
              style={{ transform: "translateZ(90px)" }}
            >
              <span className="mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-full bg-[#f4e9d2] text-espresso">
                <svg viewBox="0 0 16 16" className="h-3.5 w-3.5" fill="none" aria-hidden>
                  <path
                    d="M3 5l5 4 5-4M3 4h10v8H3z"
                    stroke="currentColor"
                    strokeWidth="1.3"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </span>
              <div>
                <p className="text-sm font-semibold leading-tight">
                  Potvrdenie odoslané
                </p>
                <p className="mt-0.5 text-xs text-espresso-soft/60">
                  E-mailom klientovi aj vám.
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ===== Admin panel majiteľa ===== */}
        <AnimatePresence>
          {state.showAdmin && (
            <motion.div
              initial={{ opacity: 0, y: 28, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 28, scale: 0.96 }}
              transition={{ duration: 0.6, ease: expoOut }}
              className="ui-card-dark absolute inset-x-2 bottom-[-1.5rem] rounded-card p-5"
              style={{ transform: "translateZ(110px)" }}
            >
              <div className="flex items-center justify-between">
                <p className="font-mono text-eyebrow uppercase text-champagne">
                  Administrácia
                </p>
                <span className="flex items-center gap-1.5 rounded-full bg-ink/10 px-2.5 py-1 text-[10px] font-medium text-ink">
                  <span className="h-1.5 w-1.5 rounded-full bg-[#5fd190]" /> Naživo
                </span>
              </div>

              <div className="mt-4 rounded-soft border border-line bg-ink/5 p-3.5">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-semibold text-ink">Nová rezervácia</p>
                  <span className="rounded-full bg-[#1f7a4d] px-2.5 py-0.5 text-[10px] font-medium text-ivory">
                    potvrdené
                  </span>
                </div>
                <div className="mt-2 flex items-center gap-3 text-xs text-muted">
                  <span>Strih + brada</span>
                  <span className="h-1 w-1 rounded-full bg-muted/50" />
                  <span>11:00</span>
                </div>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-2">
                {adminItems.map((item) => (
                  <div
                    key={item}
                    className="rounded-soft border border-line bg-ink/[0.03] px-3 py-2 text-[11px] text-ink/75"
                  >
                    {item}
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* počítadlo krokov */}
      <p className="mt-10 text-center font-mono text-[11px] uppercase tracking-[0.14em] text-muted lg:mt-12">
        Krok {index + 1} / {stages.length}
      </p>
    </div>
  );
}
