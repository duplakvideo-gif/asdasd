"use client";

import { useRef } from "react";
import {
  motion,
  useMotionValue,
  useMotionTemplate,
  useSpring,
  useTransform,
} from "framer-motion";
import { Button } from "@/components/ui/Button";
import { Marquee } from "@/components/ui/Marquee";
import { services, slots } from "@/content/data";
import { site, cta } from "@/content/site";
import { expoOut } from "@/lib/motion";

export function HeroSection() {
  const mouseX = useMotionValue(-500);
  const mouseY = useMotionValue(-500);
  const spotlight = useMotionTemplate`radial-gradient(34rem circle at ${mouseX}px ${mouseY}px, rgba(216,173,100,0.08), transparent 70%)`;

  return (
    <section
      id="top"
      className="relative overflow-hidden pt-28 md:pt-36"
      onMouseMove={(e) => {
        const r = e.currentTarget.getBoundingClientRect();
        mouseX.set(e.clientX - r.left);
        mouseY.set(e.clientY - r.top);
      }}
    >
      {/* fotka prevádzky v pozadí — teplo a realita namiesto sterilnej čiernej */}
      {/* TODO: nahradiť vlastnou fotkou salónu / barbershopu */}
      <div className="absolute inset-0" aria-hidden>
        <img
          src="https://images.unsplash.com/photo-1585747860715-2ba37e788b70?w=1920&q=70&auto=format&fit=crop"
          alt=""
          className="h-full w-full object-cover opacity-30"
        />
        <div
          className="absolute inset-0"
          style={{
            background:
              "linear-gradient(180deg, rgba(16,14,11,0.72) 0%, rgba(16,14,11,0.88) 55%, #100e0b 100%)",
          }}
        />
      </div>

      {/* spotlight sledujúci myš */}
      <motion.div
        className="pointer-events-none absolute inset-0 hidden md:block"
        style={{ background: spotlight }}
        aria-hidden
      />

      <div className="relative mx-auto w-full max-w-container px-5 md:px-8">
        {/* status riadok */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: expoOut }}
          className="flex items-center gap-3 font-mono text-[11px] uppercase tracking-[0.16em] text-muted"
        >
          <span className="flex items-center gap-2">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-champagne opacity-60" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-champagne" />
            </span>
            {site.city}, SK — voľná kapacita
          </span>
          <span className="hidden h-px flex-1 bg-line sm:block" aria-hidden />
          <span className="hidden sm:inline">[ Weby · Rezervácie · Salóny ]</span>
        </motion.div>

        {/* headline cez celú šírku */}
        <motion.h1
          initial={{ opacity: 0, y: 28 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, ease: expoOut, delay: 0.08 }}
          className="mt-8 max-w-5xl text-display-xl font-medium text-ink"
        >
          Web, ktorý <em>prijíma rezervácie.</em>
        </motion.h1>

        <div className="mt-10 grid grid-cols-1 items-end gap-10 pb-16 md:pb-20 lg:grid-cols-[1fr_auto]">
          {/* ľavý stĺpec: lead + CTA */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: expoOut, delay: 0.18 }}
            className="max-w-md"
          >
            <p className="text-base leading-relaxed text-muted sm:text-lg">
              Postavíme vám prezentačný web s rezervačným systémom
              a spustíme ho <span className="text-ink">do 48 hodín</span>.
              Zaplatíte raz. Fungujete ďalej.
            </p>

            <div className="mt-8 flex flex-col items-start gap-4 sm:flex-row sm:items-center">
              <Button href={cta.primaryHref}>{cta.primary}</Button>
              {/* TODO: nasadiť demo na demo.bookweb.sk */}
              <Button href={site.demoUrl} variant="ghost">
                {cta.secondary}
              </Button>
            </div>

            <p className="mt-7 font-mono text-[11px] uppercase tracking-[0.14em] text-muted">
              Platí sa raz · Vlastná doména · Pre salóny a lokálne služby
            </p>
          </motion.div>

          {/* pravý stĺpec: booking náhľad */}
          <HeroBookingPreview />
        </div>
      </div>

      <Marquee />
    </section>
  );
}

function HeroBookingPreview() {
  const ref = useRef<HTMLDivElement>(null);

  // jemný 3D náklon karty podľa polohy myši
  const px = useMotionValue(0.5);
  const py = useMotionValue(0.5);
  const rotateY = useSpring(useTransform(px, [0, 1], [-11, -3]), {
    stiffness: 120,
    damping: 18,
  });
  const rotateX = useSpring(useTransform(py, [0, 1], [9, 1]), {
    stiffness: 120,
    damping: 18,
  });

  return (
    <div
      ref={ref}
      className="relative lg:w-[24rem]"
      style={{ perspective: "1600px" }}
      onMouseMove={(e) => {
        const r = ref.current?.getBoundingClientRect();
        if (!r) return;
        px.set((e.clientX - r.left) / r.width);
        py.set((e.clientY - r.top) / r.height);
      }}
      onMouseLeave={() => {
        px.set(0.5);
        py.set(0.5);
      }}
    >
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1, ease: expoOut, delay: 0.25 }}
        className="floor-shadow relative mx-auto w-full max-w-[24rem]"
        style={{ transformStyle: "preserve-3d", rotateX, rotateY }}
      >
        {/* náhľad klientskeho webu — svetlá karta na tmavom pozadí */}
        <div className="ui-card overflow-hidden rounded-mock">
          <div className="browser-bar flex items-center gap-2 px-4 py-3">
            <span className="h-2.5 w-2.5 rounded-full bg-[#e0d8c8]" />
            <span className="h-2.5 w-2.5 rounded-full bg-[#e0d8c8]" />
            <span className="h-2.5 w-2.5 rounded-full bg-[#e0d8c8]" />
            <div className="ml-3 flex-1 rounded-full bg-beige/70 px-3 py-1 text-center font-mono text-[11px] text-espresso-soft/60">
              salon-luna.sk
            </div>
          </div>

          <div className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-base font-semibold tracking-tight">Salón Luna</p>
                <p className="text-xs text-espresso-soft/60">Kaderníctvo · Poprad</p>
              </div>
              <span className="rounded-full bg-beige px-3 py-1 text-[11px] font-medium text-espresso-soft">
                Online rezervácia
              </span>
            </div>

            <div className="mt-4 space-y-2">
              {services.map((s, i) => (
                <div
                  key={s.name}
                  className={`flex items-center justify-between rounded-soft border px-3.5 py-2.5 ${
                    i === 0
                      ? "border-champagne bg-[#f4e9d2]/60"
                      : "border-card-line bg-white"
                  }`}
                >
                  <div>
                    <p className="text-sm font-medium">{s.name}</p>
                    <p className="text-xs text-espresso-soft/60">{s.duration}</p>
                  </div>
                  <span className="text-sm font-medium">{s.price}</span>
                </div>
              ))}
            </div>

            <p className="mt-4 font-mono text-[10px] uppercase tracking-[0.14em] text-espresso-soft/60">
              Voľný termín — dnes
            </p>
            <div className="mt-2.5 flex flex-wrap gap-2">
              {slots.map((slot) => (
                <span
                  key={slot}
                  className={`rounded-full border px-3 py-1.5 text-xs font-medium ${
                    slot === "11:00"
                      ? "border-espresso bg-espresso text-ivory"
                      : "border-card-line text-espresso-soft"
                  }`}
                >
                  {slot}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* potvrdzovací chip */}
        <motion.div
          initial={{ opacity: 0, y: 14, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.7, ease: expoOut, delay: 1.05 }}
          className="ui-card absolute -bottom-6 -left-4 flex items-center gap-3 rounded-2xl px-4 py-3 sm:-left-8"
          style={{ transform: "translateZ(60px)" }}
        >
          <span className="grid h-9 w-9 place-items-center rounded-full bg-[#1f7a4d] text-ivory">
            <svg viewBox="0 0 16 16" className="h-4 w-4" fill="none" aria-hidden>
              <path
                d="M3.5 8.5l2.8 2.8 6-6.2"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </span>
          <div>
            <p className="text-sm font-semibold leading-tight">Rezervácia potvrdená</p>
            <p className="text-xs text-espresso-soft/60">Strih + brada · 11:00</p>
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
}
