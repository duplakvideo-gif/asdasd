"use client";

import { motion } from "framer-motion";
import { Section } from "@/components/ui/Section";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Reveal } from "@/components/ui/Reveal";
import { benefits } from "@/content/data";
import { fadeUp, stagger } from "@/lib/motion";

const icons = [
  // web
  <path key="a" d="M3 7h18M3 7v10a1 1 0 001 1h16a1 1 0 001-1V7M3 7l1.2-2.5A1 1 0 015.1 4h13.8a1 1 0 01.9.5L21 7M8 11h5" strokeWidth="1.4" />,
  // kalendár
  <path key="b" d="M4 6h16v14H4zM4 9h16M8 3v4M16 3v4M8 14l2 2 4-4" strokeWidth="1.4" />,
  // mail
  <path key="c" d="M3 6h18v12H3zM3 7l9 6 9-6" strokeWidth="1.4" />,
  // slidery
  <path key="d" d="M4 8h10M18 8h2M4 16h2M10 16h10M14 6v4M6 14v4" strokeWidth="1.4" />,
];

export function BenefitsSection() {
  return (
    <Section id="vyhody" className="hairline py-20 md:py-32">
      <div className="max-w-2xl">
        <Reveal>
          <Eyebrow no="03">Čo dostanete</Eyebrow>
        </Reveal>
        <Reveal delay={0.05}>
          <h2 className="mt-6 text-display-lg font-medium text-ink">
            Web, ktorý reálne <em>pracuje za vás.</em>
          </h2>
        </Reveal>
      </div>

      <motion.div
        variants={stagger}
        initial="hidden"
        whileInView="show"
        viewport={{ once: true, margin: "-80px" }}
        className="mt-14 grid grid-cols-1 gap-px overflow-hidden rounded-card border border-line bg-line sm:grid-cols-2"
      >
        {benefits.map((b, i) => (
          <motion.div
            key={b.title}
            variants={fadeUp}
            className="group bg-bg p-7 transition-colors duration-300 hover:bg-bg-raised md:p-9"
          >
            <div className="flex items-start justify-between">
              <span className="grid h-11 w-11 place-items-center rounded-full border border-line-strong text-ink transition-colors duration-300 group-hover:border-champagne group-hover:text-champagne">
                <svg
                  viewBox="0 0 24 24"
                  className="h-5 w-5"
                  fill="none"
                  stroke="currentColor"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  {icons[i]}
                </svg>
              </span>
              <span className="font-mono text-[11px] text-champagne/70">
                0{i + 1}
              </span>
            </div>
            <h3 className="mt-6 text-xl font-medium tracking-tight text-ink">
              {b.title}
            </h3>
            <p className="mt-3 text-base leading-relaxed text-muted">{b.text}</p>
          </motion.div>
        ))}
      </motion.div>
    </Section>
  );
}
