"use client";

import { motion } from "framer-motion";
import { Section } from "@/components/ui/Section";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Reveal } from "@/components/ui/Reveal";
import { steps } from "@/content/data";
import { fadeUp, stagger } from "@/lib/motion";

export function ProcessSection() {
  return (
    <Section id="proces" className="hairline py-20 md:py-32">
      <div className="grid grid-cols-1 gap-12 lg:grid-cols-[0.8fr_1.2fr] lg:gap-16">
        <div>
          <Reveal>
            <Eyebrow no="05">Ako to prebieha</Eyebrow>
          </Reveal>
          <Reveal delay={0.05}>
            <h2 className="mt-6 text-display-lg font-medium text-ink">
              Tri kroky, <em>nula stresu.</em>
            </h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="mt-5 text-lg leading-relaxed text-muted">
              Najprv vidíte ukážku, až potom sa rozhodujete. Celé to vybavíme
              my — vy dodáte služby a fotky.
            </p>
          </Reveal>

          {/* signature 48 h motív */}
          <Reveal delay={0.15}>
            <div className="mt-10 inline-flex items-baseline gap-3 rounded-card border border-line bg-bg-raised px-6 py-4">
              <span className="font-serif text-5xl italic text-champagne">48</span>
              <span className="font-mono text-xs uppercase tracking-[0.14em] text-muted">
                hodín od podkladov
                <br />
                po spustený web
              </span>
            </div>
          </Reveal>
        </div>

        <motion.ol
          variants={stagger}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-80px" }}
          className="relative"
        >
          {/* spojovacia línia */}
          <div
            className="absolute bottom-6 left-[1.45rem] top-6 w-px bg-line"
            aria-hidden
          />

          {steps.map((step) => (
            <motion.li
              key={step.no}
              variants={fadeUp}
              className="relative flex gap-6 pb-10 last:pb-0"
            >
              <span className="relative z-10 grid h-12 w-12 shrink-0 place-items-center rounded-full border border-line-strong bg-bg font-mono text-sm text-champagne">
                {step.no}
              </span>
              <div className="pt-1.5">
                <h3 className="text-xl font-medium tracking-tight text-ink">
                  {step.title}
                </h3>
                <p className="mt-2 max-w-md text-base leading-relaxed text-muted">
                  {step.text}
                </p>
              </div>
            </motion.li>
          ))}
        </motion.ol>
      </div>
    </Section>
  );
}
