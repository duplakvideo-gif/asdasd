"use client";

import { motion } from "framer-motion";
import { Section } from "@/components/ui/Section";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Reveal } from "@/components/ui/Reveal";
import { Button } from "@/components/ui/Button";
import { pricing } from "@/content/data";
import { cta } from "@/content/site";
import { expoOut } from "@/lib/motion";

function Check({ className = "text-champagne" }: { className?: string }) {
  return (
    <span
      className={`mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full border border-current ${className}`}
    >
      <svg viewBox="0 0 12 12" className="h-3 w-3" fill="none" aria-hidden>
        <path
          d="M2.5 6.2l2.2 2.2L9.5 3.6"
          stroke="currentColor"
          strokeWidth="1.6"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    </span>
  );
}

export function PricingSection() {
  return (
    <Section id="cennik" className="hairline warm-wash py-20 md:py-32">
      <div className="mx-auto max-w-2xl text-center">
        <Reveal className="flex justify-center">
          <Eyebrow no="04">Cenník</Eyebrow>
        </Reveal>
        <Reveal delay={0.05}>
          <h2 className="mt-6 text-display-lg font-medium text-ink">
            Zaplatíte raz. <em>Fungujete ďalej.</em>
          </h2>
        </Reveal>
        <Reveal delay={0.1}>
          <p className="mt-5 text-lg leading-relaxed text-muted">
            Dve možnosti, rovnaký web aj rezervácie. Žiadne skryté poplatky.
          </p>
        </Reveal>
      </div>

      <div className="mx-auto mt-14 grid max-w-4xl grid-cols-1 gap-4 md:grid-cols-[1.15fr_0.85fr]">
        {/* Jednorazovo — odporúčané */}
        <motion.div
          initial={{ opacity: 0, y: 28 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.8, ease: expoOut }}
          className="relative overflow-hidden rounded-card border border-champagne/50 bg-bg-raised p-8 md:p-10"
        >
          <span className="absolute right-6 top-6 rounded-full bg-champagne px-3 py-1 font-mono text-[10px] font-bold uppercase tracking-[0.12em] text-bg">
            {pricing.oneTime.tag}
          </span>

          <p className="font-mono text-eyebrow uppercase text-muted">
            Web + rezervačný systém
          </p>
          <div className="mt-4 flex items-baseline gap-3">
            <span className="font-serif text-6xl italic text-champagne">
              {pricing.oneTime.price}
            </span>
            <span className="font-mono text-xs uppercase tracking-[0.12em] text-muted">
              {pricing.oneTime.period}
            </span>
          </div>
          <p className="mt-3 text-sm leading-relaxed text-muted">
            {pricing.oneTime.note}
          </p>

          <ul className="mt-7 space-y-3">
            {pricing.oneTime.features.map((f) => (
              <li key={f} className="flex items-start gap-3 text-sm text-ink">
                <Check />
                <span className="leading-snug">{f}</span>
              </li>
            ))}
          </ul>

          {/* prevádzka / hosting — transparentne, žiadne prekvapenia */}
          <p className="mt-6 rounded-soft border border-line bg-bg px-4 py-3 text-xs leading-relaxed text-muted">
            {pricing.oneTime.hosting}
          </p>

          <Button href={cta.primaryHref} className="mt-7 w-full">
            {cta.primary}
          </Button>
        </motion.div>

        {/* Mesačne — alternatíva */}
        <motion.div
          initial={{ opacity: 0, y: 28 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.8, ease: expoOut, delay: 0.1 }}
          className="flex flex-col rounded-card border border-line bg-bg p-8 md:p-10"
        >
          <p className="font-mono text-eyebrow uppercase text-muted">
            {pricing.monthly.tag}
          </p>
          <div className="mt-4 flex items-baseline gap-3">
            <span className="text-4xl font-medium tracking-tight text-ink">
              {pricing.monthly.price}
            </span>
            <span className="font-mono text-xs uppercase tracking-[0.12em] text-muted">
              {pricing.monthly.period}
            </span>
          </div>
          <p className="mt-3 text-sm leading-relaxed text-muted">
            {pricing.monthly.note}
          </p>

          <ul className="mt-7 flex-1 space-y-3">
            {pricing.monthly.features.map((f) => (
              <li key={f} className="flex items-start gap-3 text-sm text-ink/85">
                <Check className="text-muted" />
                <span className="leading-snug">{f}</span>
              </li>
            ))}
          </ul>

          <Button href={cta.primaryHref} variant="ghost" className="mt-8 w-full">
            Nezáväzne sa opýtať
          </Button>
        </motion.div>
      </div>

      {/* porovnávacia veta */}
      <Reveal delay={0.15}>
        <p className="mx-auto mt-10 max-w-2xl text-center text-base leading-relaxed text-muted">
          {pricing.comparison}
        </p>
      </Reveal>
    </Section>
  );
}
