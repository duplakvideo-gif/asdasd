"use client";

import { motion } from "framer-motion";
import { Section } from "@/components/ui/Section";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Reveal } from "@/components/ui/Reveal";
import { about, } from "@/content/data";
import { site } from "@/content/site";
import { expoOut } from "@/lib/motion";

export function AboutSection() {
  return (
    <Section id="o-mne" className="hairline py-20 md:py-32">
      <div className="grid grid-cols-1 items-center gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16">
        {/* fotka */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.8, ease: expoOut }}
          className="relative"
        >
          {/* TODO: nahradiť vlastnou fotkou (portrét / pri práci) */}
          <img
            src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?w=900&q=75&auto=format&fit=crop"
            alt={`${about.name} — ${about.role}`}
            loading="lazy"
            className="aspect-[4/5] w-full rounded-card border border-line object-cover grayscale"
          />
          <div className="absolute bottom-4 left-4 rounded-full border border-line bg-bg/85 px-4 py-2 font-mono text-[11px] uppercase tracking-[0.14em] text-ink backdrop-blur-sm">
            {site.city}, SK
          </div>
        </motion.div>

        {/* text v prvej osobe */}
        <div>
          <Reveal>
            <Eyebrow no="08">{about.eyebrow}</Eyebrow>
          </Reveal>
          <Reveal delay={0.05}>
            <h2 className="mt-6 text-display-lg font-medium text-ink">
              Žiadna platforma. <em>Konkrétny človek.</em>
            </h2>
          </Reveal>

          <div className="mt-6 space-y-4">
            {about.paragraphs.map((p, i) => (
              <Reveal key={i} delay={0.1 + i * 0.05}>
                <p className="max-w-lg text-lg leading-relaxed text-muted">{p}</p>
              </Reveal>
            ))}
          </div>

          <Reveal delay={0.3}>
            <div className="mt-8 flex items-center gap-4 border-t border-line pt-6">
              {/* TODO: doplniť skutočné meno */}
              <p className="font-serif text-2xl italic text-champagne">
                {about.name}
              </p>
              <p className="font-mono text-xs uppercase tracking-[0.14em] text-muted">
                {about.role}
              </p>
            </div>
          </Reveal>
        </div>
      </div>
    </Section>
  );
}
