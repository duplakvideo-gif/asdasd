"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { site } from "@/content/site";
import { expoOut } from "@/lib/motion";

/*
 * Formulár dopytu — max 3 polia (každé pole navyše znižuje konverziu).
 * TODO: napojiť na skutočný endpoint (Formspree / Netlify Forms / API).
 * Zatiaľ otvorí predvyplnený e-mail — funguje bez backendu.
 */
export function ContactSection() {
  const [business, setBusiness] = useState("");
  const [contact, setContact] = useState("");
  const [city, setCity] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const subject = encodeURIComponent(`Dopyt na ukážku — ${business}`);
    const body = encodeURIComponent(
      `Prevádzka: ${business}\nKontakt: ${contact}\nMesto: ${city}\n\nChcem ukážku webu zadarmo.`,
    );
    window.location.href = `mailto:${site.email}?subject=${subject}&body=${body}`;
  };

  return (
    <section id="dopyt" className="hairline warm-wash relative py-20 md:py-32">
      <div className="mx-auto grid w-full max-w-container grid-cols-1 gap-12 px-5 md:px-8 lg:grid-cols-2 lg:gap-20">
        {/* ľavá strana — posledný krok */}
        <div>
          <Eyebrow no="09">Posledný krok</Eyebrow>
          <h2 className="mt-6 text-display-lg font-medium text-ink">
            Zanechajte prvý dojem. My sa postaráme <em>o zvyšok.</em>
          </h2>
          <p className="mt-5 max-w-md text-lg leading-relaxed text-muted">
            Napíšte názov prevádzky a mesto — do dňa-dvoch pošleme hotovú
            ukážku webu zadarmo. Žiadny záväzok.
          </p>

          <div className="mt-9 space-y-3 font-mono text-sm">
            {/* TODO: doplniť skutočné telefónne číslo */}
            <a
              href={site.phoneHref}
              className="flex items-center gap-3 text-muted transition-colors hover:text-champagne-hi"
            >
              <span className="font-bold text-champagne">tel</span>
              {site.phone}
            </a>
            <a
              href={`mailto:${site.email}`}
              className="flex items-center gap-3 text-muted transition-colors hover:text-champagne-hi"
            >
              <span className="font-bold text-champagne">@</span>
              {site.email}
            </a>
          </div>
        </div>

        {/* pravá strana — formulár */}
        <motion.form
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.8, ease: expoOut }}
          onSubmit={handleSubmit}
          className="rounded-card border border-line bg-bg-raised/60 p-7 md:p-9"
        >
          <div className="space-y-4">
            <label className="block">
              <span className="mb-2 block font-mono text-[11px] uppercase tracking-[0.14em] text-muted">
                Názov prevádzky
              </span>
              <input
                type="text"
                required
                value={business}
                onChange={(e) => setBusiness(e.target.value)}
                placeholder="napr. Salón Luna"
                className="field"
              />
            </label>

            <label className="block">
              <span className="mb-2 block font-mono text-[11px] uppercase tracking-[0.14em] text-muted">
                Telefón alebo e-mail
              </span>
              <input
                type="text"
                required
                value={contact}
                onChange={(e) => setContact(e.target.value)}
                placeholder="+421 9XX XXX XXX"
                className="field"
              />
            </label>

            <label className="block">
              <span className="mb-2 block font-mono text-[11px] uppercase tracking-[0.14em] text-muted">
                Mesto
              </span>
              <input
                type="text"
                required
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="napr. Poprad"
                className="field"
              />
            </label>
          </div>

          <button
            type="submit"
            className="group mt-7 inline-flex w-full items-center justify-center gap-2 rounded-full bg-champagne px-7 py-4 text-sm font-medium text-bg transition-all duration-300 ease-expo hover:-translate-y-0.5 hover:bg-champagne-hi hover:shadow-lift"
          >
            Odoslať dopyt
            <svg
              className="h-4 w-4 transition-transform duration-300 ease-expo group-hover:translate-x-1"
              viewBox="0 0 16 16"
              fill="none"
              aria-hidden
            >
              <path
                d="M3 8h10M9 4l4 4-4 4"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </button>

          <p className="mt-4 text-center text-xs leading-relaxed text-muted">
            Odoslaním súhlasíte so{" "}
            <a
              href="/ochrana-osobnych-udajov"
              className="underline underline-offset-2 hover:text-ink"
            >
              spracovaním osobných údajov
            </a>
            .
          </p>
        </motion.form>
      </div>
    </section>
  );
}
