"use client";

import { motion } from "framer-motion";
import { Section } from "@/components/ui/Section";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Reveal } from "@/components/ui/Reveal";
import { Button } from "@/components/ui/Button";
import { references, referencesEmptyState } from "@/content/data";
import { cta } from "@/content/site";
import { fadeUp, stagger } from "@/lib/motion";

/*
 * Referencie sa dopĺňajú v src/content/data.ts (pole `references`).
 * Kým je pole prázdne, zobrazí sa dočasný stav s CTA.
 */
export function ReferencesSection() {
  return (
    <Section id="referencie" className="hairline py-20 md:py-32">
      <div className="max-w-2xl">
        <Reveal>
          <Eyebrow no="07">Referencie</Eyebrow>
        </Reveal>
        <Reveal delay={0.05}>
          <h2 className="mt-6 text-display-lg font-medium text-ink">
            Weby, ktoré už <em>prijímajú rezervácie.</em>
          </h2>
        </Reveal>
      </div>

      {references.length === 0 ? (
        <Reveal delay={0.1}>
          <div className="mt-12 flex flex-col items-start gap-6 rounded-card border border-dashed border-line-strong bg-bg-raised/40 p-8 md:flex-row md:items-center md:justify-between md:p-10">
            <div className="max-w-xl">
              <p className="text-xl font-medium tracking-tight text-ink">
                {referencesEmptyState.title}
              </p>
              <p className="mt-2 text-base leading-relaxed text-muted">
                {referencesEmptyState.text}
              </p>
            </div>
            <Button href={cta.primaryHref} variant="ghost" className="shrink-0">
              {cta.primary}
            </Button>
          </div>
        </Reveal>
      ) : (
        <motion.div
          variants={stagger}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-80px" }}
          className="mt-12 grid grid-cols-1 gap-4 md:grid-cols-3"
        >
          {references.map((r) => (
            <motion.figure
              key={r.business}
              variants={fadeUp}
              className="flex flex-col rounded-card border border-line bg-bg-raised/50 p-7"
            >
              <span className="font-serif text-4xl italic leading-none text-champagne">
                „
              </span>
              <blockquote className="mt-2 flex-1 text-base leading-relaxed text-ink">
                {r.quote}
              </blockquote>
              <figcaption className="mt-5 border-t border-line pt-4">
                <p className="text-sm font-medium text-ink">{r.name}</p>
                <p className="font-mono text-xs text-muted">{r.business}</p>
              </figcaption>
            </motion.figure>
          ))}
        </motion.div>
      )}
    </Section>
  );
}
