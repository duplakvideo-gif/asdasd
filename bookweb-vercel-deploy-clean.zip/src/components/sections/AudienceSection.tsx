"use client";

import { motion } from "framer-motion";
import { Section } from "@/components/ui/Section";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Reveal } from "@/components/ui/Reveal";
import { audience } from "@/content/data";
import { fadeUp, stagger } from "@/lib/motion";

export function AudienceSection() {
  return (
    <Section id="pre-koho" className="hairline py-20 md:py-32">
      <div className="max-w-2xl">
        <Reveal>
          <Eyebrow no="06">Pre koho</Eyebrow>
        </Reveal>
        <Reveal delay={0.05}>
          <h2 className="mt-6 text-display-lg font-medium text-ink">
            Pre lokálne služby, kde sa pracuje <em>na termíny.</em>
          </h2>
        </Reveal>
      </div>

      <motion.div
        variants={stagger}
        initial="hidden"
        whileInView="show"
        viewport={{ once: true, margin: "-80px" }}
        className="mt-14 grid grid-cols-2 gap-3 md:grid-cols-3 md:gap-4"
      >
        {audience.map((a) => (
          <motion.div
            key={a.title}
            variants={fadeUp}
            className="photo-overlay group relative aspect-[4/5] overflow-hidden rounded-card border border-line sm:aspect-[4/3]"
          >
            {/* TODO: nahradiť vlastnou fotkou prevádzky */}
            <img
              src={a.img}
              alt={a.title}
              loading="lazy"
              className="h-full w-full object-cover transition-transform duration-700 ease-expo group-hover:scale-105"
            />
            <div className="absolute inset-x-0 bottom-0 z-10 p-5 md:p-6">
              <span className="block h-1.5 w-1.5 rotate-45 bg-champagne transition-transform duration-300 group-hover:scale-150" />
              <h3 className="mt-3 text-lg font-medium tracking-tight text-ink">
                {a.title}
              </h3>
              <p className="mt-1 text-sm text-ink/70">{a.text}</p>
            </div>
          </motion.div>
        ))}
      </motion.div>
    </Section>
  );
}
