"use client";

import { motion } from "framer-motion";
import { Section } from "@/components/ui/Section";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Reveal } from "@/components/ui/Reveal";
import { problems } from "@/content/data";
import { expoOut, fadeUp, stagger } from "@/lib/motion";

export function ProblemSection() {
  return (
    <Section id="problem" className="py-20 md:py-32">
      <div className="max-w-2xl">
        <Reveal>
          <Eyebrow no="01">Ako to vyzerá dnes</Eyebrow>
        </Reveal>
        <Reveal delay={0.05}>
          <h2 className="mt-6 text-display-lg font-medium text-ink">
            Rezervácie roztrúsené na <em>piatich miestach</em> naraz.
          </h2>
        </Reveal>
        <Reveal delay={0.1}>
          <p className="mt-5 text-lg leading-relaxed text-muted">
            Telefonáty, Instagram, Messenger, papierový diár. Každý kanál
            zvlášť, nič nesedí. Výsledok je chaos — a občas aj dvaja klienti na
            rovnaký čas.
          </p>
        </Reveal>
      </div>

      <div className="mt-14 grid grid-cols-1 items-center gap-10 lg:grid-cols-[1fr_auto_0.9fr]">
        {/* roztrúsené problémy — kontrolovaná mriežka */}
        <motion.div
          variants={stagger}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-80px" }}
          className="grid grid-cols-1 gap-3 sm:grid-cols-2"
        >
          {problems.map((p) => (
            <motion.div
              key={p.channel}
              variants={fadeUp}
              className="rounded-soft border border-line bg-bg-raised/60 p-4"
            >
              <p className="font-mono text-[11px] uppercase tracking-[0.14em] text-muted">
                {p.channel}
              </p>
              <p className="mt-2 text-sm font-medium leading-snug text-ink">
                {p.text}
              </p>
              <p className="mt-2 text-xs text-muted">{p.note}</p>
            </motion.div>
          ))}
        </motion.div>

        {/* šípka zlúčenia */}
        <Reveal delay={0.15}>
          <div className="flex items-center justify-center gap-3 lg:flex-col">
            <span className="font-mono text-[11px] uppercase tracking-[0.14em] text-muted">
              všetko do
            </span>
            <svg
              viewBox="0 0 48 24"
              className="h-6 w-12 text-champagne lg:hidden"
              fill="none"
              aria-hidden
            >
              <path
                d="M4 12h36M32 5l8 7-8 7"
                stroke="currentColor"
                strokeWidth="1.6"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            <svg
              viewBox="0 0 24 48"
              className="hidden h-12 w-6 text-champagne lg:block"
              fill="none"
              aria-hidden
            >
              <path
                d="M12 4v36M5 32l7 8 7-8"
                stroke="currentColor"
                strokeWidth="1.6"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
        </Reveal>

        {/* jeden čistý tok */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.8, ease: expoOut }}
          className="rounded-card border border-champagne/30 bg-bg-raised p-6"
        >
          <p className="font-mono text-eyebrow uppercase text-champagne">
            Jedno miesto
          </p>
          <p className="mt-3 text-xl font-medium tracking-tight text-ink">
            Web s rezervačným systémom
          </p>
          <div className="mt-5 space-y-3">
            {[
              "Klient si vyberie službu",
              "Vyberie voľný termín",
              "Dostane email potvrdenie",
              "Vy máte termín v diári",
            ].map((line, i) => (
              <div key={line} className="flex items-center gap-3">
                <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full border border-champagne/40 font-mono text-[11px] text-champagne">
                  {i + 1}
                </span>
                <span className="text-sm text-ink/90">{line}</span>
              </div>
            ))}
          </div>
          <div className="mt-6 flex items-center gap-2 rounded-soft border border-line bg-bg px-3.5 py-2.5">
            <span className="h-2 w-2 rounded-full bg-[#5fd190]" />
            <span className="text-xs text-ink/80">
              Bez chaosu. Bez dvojitých rezervácií.
            </span>
          </div>
        </motion.div>
      </div>
    </Section>
  );
}
