import { Header } from "@/components/ui/Header";
import { Footer } from "@/components/ui/Footer";
import { HeroSection } from "@/components/sections/HeroSection";
import { ProblemSection } from "@/components/sections/ProblemSection";
import { BookingScrollDemo } from "@/components/sections/BookingScrollDemo";
import { BenefitsSection } from "@/components/sections/BenefitsSection";
import { PricingSection } from "@/components/sections/PricingSection";
import { ProcessSection } from "@/components/sections/ProcessSection";
import { AudienceSection } from "@/components/sections/AudienceSection";
import { ReferencesSection } from "@/components/sections/ReferencesSection";
import { AboutSection } from "@/components/sections/AboutSection";
import { ContactSection } from "@/components/sections/ContactSection";

export default function Home() {
  return (
    <>
      <Header />
      <main className="relative">
        <HeroSection />
        <ProblemSection />
        <BookingScrollDemo />
        <BenefitsSection />
        <PricingSection />
        <ProcessSection />
        <AudienceSection />
        <ReferencesSection />
        <AboutSection />
        <ContactSection />
      </main>
      <Footer />
    </>
  );
}
