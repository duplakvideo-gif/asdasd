import type { Metadata, Viewport } from "next";
import { Space_Grotesk, Instrument_Serif, Space_Mono } from "next/font/google";
import Script from "next/script";
import "./globals.css";

/*
 * Fonty: Space Grotesk (display + body — presný, remeselný grotesk),
 * Instrument Serif italic (zvýraznené slová — "drahý" editorial detail),
 * Space Mono (technické labely a číslovanie sekcií).
 * Všetky tri podporujú slovenskú diakritiku (latin-ext).
 */
const grotesk = Space_Grotesk({
  subsets: ["latin", "latin-ext"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-grotesk",
  display: "swap",
});

const serif = Instrument_Serif({
  subsets: ["latin", "latin-ext"],
  weight: "400",
  style: ["normal", "italic"],
  variable: "--font-serif",
  display: "swap",
});

const mono = Space_Mono({
  subsets: ["latin", "latin-ext"],
  weight: ["400", "700"],
  variable: "--font-mono",
  display: "swap",
});

const title = "BookWEB — web s rezerváciami pre salóny do 48 hodín";
const description =
  "Prezentačný web s rezervačným systémom pre barberov, kaderníctva, kozmetiku a masážne štúdiá. Spustenie do 48 hodín, platí sa raz — žiadny mesačný paušál navždy.";
const gtmId = "GTM-T6NPXL9Q";

export const metadata: Metadata = {
  metadataBase: new URL("https://bookweb.sk"),
  applicationName: "BookWEB",
  title: {
    default: title,
    template: "%s | BookWEB",
  },
  description,
  keywords: [
    "rezervačný systém",
    "online rezervácie",
    "web pre kaderníctvo",
    "web pre barbershop",
    "rezervácie pre salón",
    "prezentačný web",
    "web do 48 hodín",
  ],
  alternates: { canonical: "https://bookweb.sk" },
  openGraph: {
    title,
    description,
    url: "https://bookweb.sk",
    siteName: "BookWEB",
    type: "website",
    locale: "sk_SK",
  },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#0c0b09",
  colorScheme: "dark",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="sk"
      className={`${grotesk.variable} ${serif.variable} ${mono.variable}`}
    >
      <head>
        <Script id="google-tag-manager" strategy="afterInteractive">
          {`
            (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
            new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
            j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
            'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
            })(window,document,'script','dataLayer','${gtmId}');
          `}
        </Script>
      </head>
      <body className="font-sans antialiased">
        <noscript>
          <iframe
            src={`https://www.googletagmanager.com/ns.html?id=${gtmId}`}
            height="0"
            width="0"
            style={{ display: "none", visibility: "hidden" }}
          />
        </noscript>
        {children}
      </body>
    </html>
  );
}
