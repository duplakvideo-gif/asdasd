import type { Metadata } from "next";
import { site } from "@/content/site";

export const metadata: Metadata = {
  title: "Ochrana osobných údajov",
  robots: { index: false },
};

/* TODO: nahradiť placeholder text skutočným GDPR dokumentom
   (doplniť obchodné meno, IČO, sídlo a rozsah spracovania). */
export default function PrivacyPage() {
  return (
    <main className="mx-auto max-w-2xl px-5 py-24 md:px-8 md:py-32">
      <a
        href="/"
        className="font-mono text-xs uppercase tracking-[0.14em] text-muted transition-colors hover:text-champagne-hi"
      >
        ← Späť na hlavnú stránku
      </a>

      <h1 className="mt-8 text-display-lg font-medium text-ink">
        Ochrana osobných <em>údajov</em>
      </h1>

      <div className="mt-10 space-y-8 text-base leading-relaxed text-muted">
        <section>
          <h2 className="mb-3 text-lg font-medium text-ink">
            1. Prevádzkovateľ
          </h2>
          <p>
            Prevádzkovateľom osobných údajov je [Obchodné meno], IČO:
            [doplniť], so sídlom [doplniť]. Kontakt:{" "}
            <a href={`mailto:${site.email}`} className="text-ink underline underline-offset-2">
              {site.email}
            </a>
            .
          </p>
        </section>

        <section>
          <h2 className="mb-3 text-lg font-medium text-ink">
            2. Aké údaje spracúvame
          </h2>
          <p>
            Prostredníctvom formulára dopytu spracúvame názov prevádzky,
            kontaktný údaj (telefón alebo e-mail) a mesto — výlučne za účelom
            odpovede na váš dopyt a prípravy ukážky webu.
          </p>
        </section>

        <section>
          <h2 className="mb-3 text-lg font-medium text-ink">
            3. Doba uchovávania
          </h2>
          <p>
            Údaje z dopytu uchovávame najviac 12 mesiacov od poslednej
            komunikácie, alebo do odvolania súhlasu.
          </p>
        </section>

        <section>
          <h2 className="mb-3 text-lg font-medium text-ink">4. Vaše práva</h2>
          <p>
            Máte právo na prístup k údajom, ich opravu, vymazanie, obmedzenie
            spracovania a právo podať sťažnosť na Úrad na ochranu osobných
            údajov SR. Stačí nám napísať na {site.email}.
          </p>
        </section>
      </div>
    </main>
  );
}
