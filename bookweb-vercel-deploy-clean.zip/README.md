# BookWeb.sk

Moderný landing page pre **BookWeb.sk** — službu, ktorá tvorí prezentačné weby
s vstavaným rezervačným systémom pre salóny, barberov, kozmetiku, wellness,
masáže a lokálne služby.

> **Web, ktorý prijíma rezervácie.**

## Stack

- **Next.js 14** (App Router)
- **TypeScript**
- **Tailwind CSS 3**
- **Framer Motion 11** (`useScroll` / `useTransform` pre scroll-driven demo)
- Fonty: **Fraunces** (serif, display) + **Geist** (sans / mono)

Žiadne generované obrázky, žiadny Three.js — celé rozhranie je postavené
z reálnych HTML/CSS prvkov.

## Spustenie

```bash
npm install
npm run dev     # http://localhost:3000
npm run build   # produkčný build
```

## Štruktúra

```
src/
  app/
    layout.tsx          # fonty, metadata, SEO
    page.tsx            # poskladanie sekcií
    globals.css         # design tokens (ivory/espresso/champagne) + UI povrchy
    fonts/Fraunces.woff2
  content/
    site.ts             # názov, navigácia
    data.ts             # služby, sloty, admin položky, copy
  lib/
    motion.ts           # zdieľané easing + varianty
    utils.ts
  components/
    ui/                 # Section, Eyebrow, Button, Reveal, Header, Footer
    sections/
      HeroSection.tsx
      ProblemSection.tsx
      BookingScrollDemo.tsx   # ⭐ sticky scroll-driven rezervačné demo (440vh)
      BenefitsSection.tsx
      ProcessSection.tsx
      AudienceSection.tsx
      PricingSection.tsx
      CTASection.tsx
```

## Scroll-driven booking demo

`BookingScrollDemo` je hlavný prvok stránky. Sticky sekcia (440vh) prevedie
návštevníka 6 fázami reálnej rezervácie podľa pozície scrollu:

1. Web — klient otvorí stránku so službami
2. Výber služby — „Strih + brada“ sa označí
3. Termín — kalendár sa vysunie v 3D, kurzor mieri na 11:00
4. Potvrdenie — slot 11:00 sa potvrdí (check), zobrazí sa potvrdzovacia karta
5. E-mail — vysunie sa karta „Potvrdenie odoslané“
6. Majiteľ — rozhranie sa pootočí a odhalí administračný panel

Na mobile sa 3D rotácia tlmí a obsah sa stohuje (`tilt` faktor + responzívny
layout). Rešpektuje `prefers-reduced-motion`.
